add your appstate by adding a json file, 
you can enter any name of the appstate you want,
just make sure the file is ends with ".json".

example : ryuko.json